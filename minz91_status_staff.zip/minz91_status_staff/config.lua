Config = {
    staffgroup ={    ---------------------------character table
        owner ='owner',
        hadmin ='hadmin',
        admin ='admin',
        mod ='mod',
        helper ='helper',
    },

}
